import { useState, useEffect } from 'react';
import { 
  Wind, 
  ShieldCheck, 
  Moon, 
  Zap, 
  ShoppingCart, 
  Menu, 
  X, 
  Check, 
  Star,
  Leaf,
  Phone,
  Mail,
  MapPin,
  Loader2,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface Product {
  id: number;
  name: string;
  description: string;
  price: number;
  discountPercent: number;
  image: string;
}

export default function LandingPage() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [cartCount, setCartCount] = useState(0);
  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  const [isOrderModalOpen, setIsOrderModalOpen] = useState(false);
  const [orderForm, setOrderForm] = useState({ name: '', phone: '' });
  const [orderStatus, setOrderStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');

  useEffect(() => {
    fetch('/api/products')
      .then(res => res.json())
      .then(data => {
        if (data && data.length > 0) {
          setProduct(data[0]);
        }
        setLoading(false);
      })
      .catch(err => {
        console.error("Failed to fetch products", err);
        setLoading(false);
      });
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <Loader2 className="w-10 h-10 text-emerald-600 animate-spin" />
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <p className="text-slate-500">Product not found. Please try again later.</p>
      </div>
    );
  }

  const originalPrice = product.price;
  const discountPercent = product.discountPercent;
  const discountAmount = originalPrice * (discountPercent / 100);
  const finalPrice = originalPrice - discountAmount;

  const features = [
    {
      icon: <ShieldCheck className="w-6 h-6 text-emerald-600" />,
      title: "HEPA-Exceeding Filter",
      description: "Captures 99.97% of dust, smoke, pet dander & allergens."
    },
    {
      icon: <Moon className="w-6 h-6 text-sky-600" />,
      title: "Quiet Operation",
      description: "Whisper-quiet performance ensures no disturbance while sleeping."
    },
    {
      icon: <Wind className="w-6 h-6 text-emerald-600" />,
      title: "Odor Control",
      description: "Advanced technology removes bad smells and cooking odors."
    },
    {
      icon: <Zap className="w-6 h-6 text-sky-600" />,
      title: "Energy Efficient",
      description: "Low power consumption for continuous 24/7 operation."
    }
  ];

  const faqs = [
    {
      question: "How often do I need to change the filter?",
      answer: "For optimal performance, we recommend changing the filter every 6-12 months depending on usage and air quality."
    },
    {
      question: "Does it come with a warranty?",
      answer: "Yes, the Shark HP072 comes with a 1-year official warranty covering manufacturing defects."
    },
    {
      question: "Is it suitable for large rooms?",
      answer: "It is designed for rooms up to 1000 sq. ft., making it perfect for master bedrooms, living rooms, and offices."
    },
    {
      question: "What is the delivery time?",
      answer: "We offer free delivery within Dhaka city in 24-48 hours. Outside Dhaka, it takes 2-3 days via courier."
    }
  ];

  const reviews = [
    {
      name: "Rahim Ahmed",
      location: "Gulshan, Dhaka",
      rating: 5,
      comment: "Excellent purifier! My allergies have significantly reduced since I started using it. Very quiet too."
    },
    {
      name: "Farhana Islam",
      location: "Uttara, Dhaka",
      rating: 5,
      comment: "Best investment for my baby's nursery. The air feels so much fresher. Highly recommended!"
    },
    {
      name: "Tanvir Hasan",
      location: "Chittagong",
      rating: 4,
      comment: "Great product and fast delivery. The design is very modern and fits well in my living room."
    }
  ];

  const handleAddToCart = () => {
    setIsOrderModalOpen(true);
  };

  const handleOrderSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setOrderStatus('submitting');

    try {
      const response = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          productId: product.id,
          quantity: 1,
          customerName: orderForm.name,
          customerPhone: orderForm.phone
        })
      });

      if (response.ok) {
        setOrderStatus('success');
        setCartCount(prev => prev + 1);
        setTimeout(() => {
          setIsOrderModalOpen(false);
          setOrderStatus('idle');
          setOrderForm({ name: '', phone: '' });
        }, 2000);
      } else {
        setOrderStatus('error');
      }
    } catch (error) {
      setOrderStatus('error');
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-900">
      {/* Navigation */}
      <nav className="fixed w-full z-50 bg-white/80 backdrop-blur-md border-b border-slate-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <div className="flex-shrink-0 flex items-center gap-2 cursor-pointer">
              <div className="bg-gradient-to-br from-emerald-500 to-sky-500 p-2 rounded-lg text-white">
                <Wind size={24} />
              </div>
              <span className="font-bold text-xl tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-emerald-600 to-sky-600">
                HealthyAir BD
              </span>
            </div>

            {/* Desktop Menu */}
            <div className="hidden md:flex items-center space-x-8">
              <a href="#home" className="text-slate-600 hover:text-emerald-600 font-medium transition-colors">Home</a>
              <a href="#features" className="text-slate-600 hover:text-emerald-600 font-medium transition-colors">Features</a>
              <a href="#specs" className="text-slate-600 hover:text-emerald-600 font-medium transition-colors">Specs</a>
              <a href="#reviews" className="text-slate-600 hover:text-emerald-600 font-medium transition-colors">Reviews</a>
              <a href="#contact" className="text-slate-600 hover:text-emerald-600 font-medium transition-colors">Contact</a>
              
              <button 
                onClick={handleAddToCart}
                className="relative p-2 text-slate-600 hover:text-emerald-600 transition-colors"
              >
                <ShoppingCart size={24} />
                {cartCount > 0 && (
                  <span className="absolute top-0 right-0 bg-red-500 text-white text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">
                    {cartCount}
                  </span>
                )}
              </button>
            </div>

            {/* Mobile Menu Button */}
            <div className="md:hidden flex items-center">
              <button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="text-slate-600 hover:text-slate-900 focus:outline-none"
              >
                {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="md:hidden bg-white border-b border-slate-200 overflow-hidden"
            >
              <div className="px-4 pt-2 pb-4 space-y-1">
                <a href="#home" className="block px-3 py-2 rounded-md text-base font-medium text-slate-700 hover:text-emerald-600 hover:bg-slate-50">Home</a>
                <a href="#features" className="block px-3 py-2 rounded-md text-base font-medium text-slate-700 hover:text-emerald-600 hover:bg-slate-50">Features</a>
                <a href="#specs" className="block px-3 py-2 rounded-md text-base font-medium text-slate-700 hover:text-emerald-600 hover:bg-slate-50">Specs</a>
                <a href="#reviews" className="block px-3 py-2 rounded-md text-base font-medium text-slate-700 hover:text-emerald-600 hover:bg-slate-50">Reviews</a>
                <a href="#contact" className="block px-3 py-2 rounded-md text-base font-medium text-slate-700 hover:text-emerald-600 hover:bg-slate-50">Contact</a>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>

      {/* Order Modal */}
      <AnimatePresence>
        {isOrderModalOpen && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center px-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsOrderModalOpen(false)}
              className="absolute inset-0 bg-black/50 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden"
            >
              <div className="p-6">
                <div className="flex justify-between items-center mb-6">
                  <h3 className="text-xl font-bold text-slate-900">Place Your Order</h3>
                  <button onClick={() => setIsOrderModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                    <X size={24} />
                  </button>
                </div>

                {orderStatus === 'success' ? (
                  <div className="text-center py-8">
                    <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Check className="w-8 h-8 text-emerald-600" />
                    </div>
                    <h4 className="text-xl font-bold text-slate-900 mb-2">Order Placed!</h4>
                    <p className="text-slate-600">We will contact you shortly to confirm.</p>
                  </div>
                ) : (
                  <form onSubmit={handleOrderSubmit} className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">Full Name</label>
                      <input 
                        type="text" 
                        required
                        value={orderForm.name}
                        onChange={e => setOrderForm({...orderForm, name: e.target.value})}
                        className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                        placeholder="Enter your name"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">Phone Number</label>
                      <input 
                        type="tel" 
                        required
                        value={orderForm.phone}
                        onChange={e => setOrderForm({...orderForm, phone: e.target.value})}
                        className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                        placeholder="Enter your phone number"
                      />
                    </div>
                    
                    <div className="bg-slate-50 p-4 rounded-lg border border-slate-100 mt-4">
                      <div className="flex justify-between text-sm mb-2">
                        <span className="text-slate-600">Product</span>
                        <span className="font-medium text-slate-900">{product.name}</span>
                      </div>
                      <div className="flex justify-between text-sm mb-2">
                        <span className="text-slate-600">Price</span>
                        <span className="font-medium text-slate-900">৳{finalPrice.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between text-sm font-bold text-emerald-600 pt-2 border-t border-slate-200">
                        <span>Total</span>
                        <span>৳{finalPrice.toLocaleString()}</span>
                      </div>
                    </div>

                    <button 
                      type="submit" 
                      disabled={orderStatus === 'submitting'}
                      className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-lg shadow-emerald-200 transition-all transform active:scale-95 flex items-center justify-center gap-2"
                    >
                      {orderStatus === 'submitting' ? (
                        <Loader2 className="animate-spin" />
                      ) : (
                        <>
                          <ShoppingCart size={20} />
                          Confirm Order
                        </>
                      )}
                    </button>
                  </form>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Hero Section */}
      <section id="home" className="pt-24 pb-12 md:pt-32 md:pb-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            className="space-y-6"
          >
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 text-sm font-medium">
              <Leaf size={16} />
              <span> We sell entier Bangladesh</span>
            </div>
            
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-slate-900 leading-tight">
              Breathe Pure, <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-600 to-sky-600">
                Live Healthy
              </span>
            </h1>
            
            <p className="text-lg text-slate-600 max-w-lg">
              {product.description}
            </p>

            <div className="flex items-baseline gap-4">
              <span className="text-4xl font-bold text-slate-900">৳{finalPrice.toLocaleString()}</span>
              <span className="text-xl text-slate-400 line-through">৳{originalPrice.toLocaleString()}</span>
              <span className="px-2 py-1 bg-red-100 text-red-700 text-sm font-bold rounded-md">
                {discountPercent}% OFF
              </span>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <button 
                onClick={handleAddToCart}
                className="px-8 py-4 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-lg shadow-emerald-200 transition-all transform hover:-translate-y-1 flex items-center justify-center gap-2"
              >
                <ShoppingCart size={20} />
                Buy Now
              </button>
              <a 
                href="#features"
                className="px-8 py-4 bg-white border border-slate-200 text-slate-700 font-semibold rounded-xl hover:bg-slate-50 transition-colors flex items-center justify-center"
              >
                Learn More
              </a>
            </div>
            
            <div className="flex items-center gap-4 text-sm text-slate-500 pt-4">
              <div className="flex items-center gap-1">
                <Check size={16} className="text-emerald-500" />
                <span>Free Delivery in Dhaka</span>
              </div>
              <div className="flex items-center gap-1">
                <Check size={16} className="text-emerald-500" />
                <span>1 Year Warranty</span>
              </div>
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="relative"
          >
            <div className="absolute inset-0 bg-gradient-to-tr from-emerald-100 to-sky-100 rounded-full filter blur-3xl opacity-70 animate-pulse"></div>
            <div className="relative bg-white p-8 rounded-3xl shadow-2xl border border-slate-100">
              <img 
                src={product.image}
                alt={product.name}
                className="w-full h-auto object-contain rounded-xl hover:scale-105 transition-transform duration-500"
                referrerPolicy="no-referrer"
              />
              <div className="absolute top-6 right-6 bg-white/90 backdrop-blur px-3 py-1 rounded-full shadow-sm flex items-center gap-1">
                <Star size={16} className="text-yellow-400 fill-yellow-400" />
                <span className="font-bold text-sm">4.9/5</span>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features Grid */}
      <section id="features" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">Why Choose Shark HP072?</h2>
            <p className="text-slate-600 max-w-2xl mx-auto">
              Engineered for performance and designed for your home. Experience the difference of truly clean air.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="p-6 bg-slate-50 rounded-2xl border border-slate-100 hover:shadow-lg transition-shadow"
              >
                <div className="mb-4 bg-white w-12 h-12 rounded-xl flex items-center justify-center shadow-sm">
                  {feature.icon}
                </div>
                <h3 className="text-xl font-bold text-slate-900 mb-2">{feature.title}</h3>
                <p className="text-slate-600">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Detailed Specs */}
      <section id="specs" className="py-20 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white rounded-3xl shadow-xl overflow-hidden border border-slate-100">
            <div className="grid md:grid-cols-2">
              <div className="p-8 md:p-12 space-y-8">
                <h2 className="text-3xl font-bold text-slate-900">Technical Specifications</h2>
                
                <div className="space-y-4">
                  {[
                    "Model: Shark HP072",
                    "Coverage Area: Up to 1000 sq. ft.",
                    "Filter Type: HEPA-Exceeding",
                    "Noise Level: Ultra-Quiet Sleep Mode",
                    "Sensors: Real-time Air Quality Monitoring",
                    "Dimensions: Compact & Modern Design",
                    "Power: Energy Star Certified"
                  ].map((spec, i) => (
                    <div key={i} className="flex items-center gap-3">
                      <div className="flex-shrink-0 w-6 h-6 rounded-full bg-emerald-100 flex items-center justify-center">
                        <Check size={14} className="text-emerald-600" />
                      </div>
                      <span className="text-slate-700 font-medium">{spec}</span>
                    </div>
                  ))}
                </div>

                <div className="pt-6 border-t border-slate-100">
                  <h3 className="text-lg font-bold text-slate-900 mb-3">Perfect For:</h3>
                  <div className="flex flex-wrap gap-3">
                    <span className="px-4 py-2 bg-sky-50 text-sky-700 rounded-full text-sm font-medium">Bedroom</span>
                    <span className="px-4 py-2 bg-sky-50 text-sky-700 rounded-full text-sm font-medium">Nursery</span>
                    <span className="px-4 py-2 bg-sky-50 text-sky-700 rounded-full text-sm font-medium">Home Office</span>
                    <span className="px-4 py-2 bg-sky-50 text-sky-700 rounded-full text-sm font-medium">Living Room</span>
                  </div>
                </div>
              </div>
              
              <div className="bg-gradient-to-br from-emerald-600 to-sky-600 p-8 md:p-12 text-white flex flex-col justify-center items-center text-center">
                <h3 className="text-2xl font-bold mb-6">Limited Time Offer</h3>
                <div className="text-6xl font-bold mb-2">5% OFF</div>
                <p className="text-emerald-100 mb-8 text-lg">Get the best price in Bangladesh today.</p>
                
                <div className="bg-white/10 backdrop-blur-md rounded-xl p-6 w-full max-w-sm border border-white/20">
                  <div className="flex justify-between mb-2 text-emerald-100">
                    <span>Regular Price</span>
                    <span className="line-through">৳{originalPrice.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between mb-4 text-white font-bold text-xl">
                    <span>Deal Price</span>
                    <span>৳{finalPrice.toLocaleString()}</span>
                  </div>
                  <button 
                    onClick={handleAddToCart}
                    className="w-full py-3 bg-white text-emerald-600 font-bold rounded-lg hover:bg-emerald-50 transition-colors shadow-lg"
                  >
                    Claim Offer Now
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Reviews Section */}
      <section id="reviews" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">Customer Reviews</h2>
            <p className="text-slate-600">See what our happy customers are saying.</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {reviews.map((review, i) => (
              <div key={i} className="bg-slate-50 p-6 rounded-2xl border border-slate-100">
                <div className="flex gap-1 mb-4">
                  {[...Array(review.rating)].map((_, j) => (
                    <Star key={j} size={16} className="text-yellow-400 fill-yellow-400" />
                  ))}
                </div>
                <p className="text-slate-700 mb-4 italic">"{review.comment}"</p>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-emerald-100 rounded-full flex items-center justify-center text-emerald-700 font-bold">
                    {review.name[0]}
                  </div>
                  <div>
                    <div className="font-bold text-slate-900">{review.name}</div>
                    <div className="text-xs text-slate-500">{review.location}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 bg-slate-50">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">Frequently Asked Questions</h2>
          </div>
          <div className="space-y-4">
            {faqs.map((faq, i) => (
              <div key={i} className="bg-white rounded-xl border border-slate-200 overflow-hidden">
                <details className="group">
                  <summary className="flex justify-between items-center p-6 cursor-pointer list-none">
                    <span className="font-medium text-slate-900">{faq.question}</span>
                    <span className="transition group-open:rotate-180">
                      <ChevronDown size={20} className="text-slate-400" />
                    </span>
                  </summary>
                  <div className="px-6 pb-6 text-slate-600">
                    {faq.answer}
                  </div>
                </details>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact / Footer */}
      <footer id="contact" className="bg-slate-900 text-slate-300 py-12 border-t border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4 text-white">
                <Wind className="text-emerald-500" />
                <span className="font-bold text-xl">HealthyAir BD</span>
              </div>
              <p className="text-slate-400 text-sm leading-relaxed">
                Dedicated to providing clean, healthy air solutions for homes across Bangladesh. 
                Official distributor of premium air purification systems.
              </p>
            </div>
            
            <div>
              <h4 className="text-white font-bold mb-4">Contact Us</h4>
              <ul className="space-y-3 text-sm">
                <li className="flex items-center gap-2">
                  <Phone size={16} className="text-emerald-500" />
                  <span>+880 1749167870</span>
                </li>
                <li className="flex items-center gap-2">
                  <Mail size={16} className="text-emerald-500" />
                  <span>healthyairbd@gmail.com</span>
                </li>
                <li className="flex items-center gap-2">
                  <MapPin size={16} className="text-emerald-500" />
                  <span> Dhaka, Bangladesh</span>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="text-white font-bold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="#home" className="hover:text-emerald-500 transition-colors">Home</a></li>
                <li><a href="#features" className="hover:text-emerald-500 transition-colors">Features</a></li>
                <li><a href="#specs" className="hover:text-emerald-500 transition-colors">Specifications</a></li>
                <li><a href="#reviews" className="hover:text-emerald-500 transition-colors">Reviews</a></li>
                <li><a href="#" className="hover:text-emerald-500 transition-colors">Privacy Policy</a></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-slate-800 pt-8 text-center text-xs text-slate-500">
            <p>&copy; {new Date().getFullYear()} HealthyAir BD. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
