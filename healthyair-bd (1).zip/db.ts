import Database from 'better-sqlite3';

const db = new Database('store.db');

// Initialize database
db.exec(`
  CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    description TEXT NOT NULL,
    price INTEGER NOT NULL,
    discountPercent INTEGER DEFAULT 0,
    image TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    product_id INTEGER NOT NULL,
    quantity INTEGER NOT NULL,
    customer_name TEXT,
    customer_phone TEXT,
    status TEXT DEFAULT 'pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products (id)
  );
`);

// Seed data if empty
const stmt = db.prepare('SELECT count(*) as count FROM products');
const row = stmt.get() as { count: number };

if (row.count === 0) {
  const insert = db.prepare(`
    INSERT INTO products (name, description, price, discountPercent, image)
    VALUES (?, ?, ?, ?, ?)
  `);
  
  insert.run(
    'Shark HP072 Air Purifier',
    'Keep your home fresh and healthy with this powerful yet compact air purifier.',
    35000,
    5,
    'https://m.media-amazon.com/images/I/71-MxuNK6GL._AC_SL1000__.jpg'
  );
  console.log('Database seeded with initial product.');
}

export default db;
